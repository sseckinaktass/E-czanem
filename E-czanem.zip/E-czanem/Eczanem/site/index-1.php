<!DOCTYPE html>
<html lang="tr">
    <head>
    <title>Reçete Sorgulama</title>
    <meta charset="utf-8">
    <meta name="description" content="İlaçlarınızı kurye ile istediğiniz adrese teslim için tıklayınız.">
    <meta name="keywords" content="Eczanem,eczane,E-czanem,ilaç,kurye">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.1.1.js"></script>
    <script src="js/bgstretcher.js"></script>
    <script>
	$(function(){
      $('BODY').bgStretcher({
        images: ['images/slide-1.jpg'], 
		imageWidth: 1600, 
		imageHeight: 964, 
		resizeProportionally:true	
       });	
    });
    </script>
    
    </head>
    <body>
<div class="extra-block"> 
   
      <div class="row-top">
    <div class="main">
          <ul class="list-soc">
        <li><a href="#"><img alt="" src="images/soc-icon1.png"></a></li>
        <li><a href="#"><img alt="" src="images/soc-icon2.png"></a></li>
      </ul>
        </div>
  </div>
      
     
      
      <header>
    <div class="row-nav">
        <div class="main">
          <h1 class="logo"><a href="index.html"><img height="200px" width="250px" alt="E-czanem" src="images/logoeczanem.png"></a></h1>
        <nav>
           <ul class="menu">
            <li><a href="index.html">Anasayfa</a></li>
            <li class="current"><a href="index-1.php">Reçete Sorgulama</a></li>
            <li><a href="index-2.html">Ürünler</a></li>
            <li><a href="index-4.html">İletişim</a></li>
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      </div>
  </header>
 
    <section id="content">
  
    <div class="main-block">
    <div class="container_12">
          <div class="wrapper border-vert">
        <article class="grid_5">
              
              <figure class="img-rounded"><img src="images/page2-img1.jpg" width="350" height="300"  alt="" /> </figure>
              <h4>Reçete Sorgulama</h4>
              <p>Eczanelerin mesai saati mi geçti? Eczaneye gidecek imkanınız mı yok? Siz zahmet etmeyin biz getirelim. Evinizde, iş yerinizde ya da herhangi bir yerde; mekan fark etmeksizin sizin için ilaçlarınızı ayağınıza getiriyoruz. Siparişinizi oluşturun ve arkanıza yaslanın. Sağlıklı Günler:) </p>
            


            






              <form action="" method="POST">
    Reçete No <input type="text" name="ad" placeholder="Reçete no giriniz.">
    <input type="submit" value="Reçete Sorgula" name="">

              </form>  
        </article>
              <article class="grid_3 prefix_2">
                <ul class="list-services">
              <li>
                <a></a>
                <?php



if(isset($_POST['ad'])){
    $sayi = $_POST['ad'];

    switch($sayi){
      case "3665":
        echo "<h1>REÇETE NO: 3665</h1>";
        echo "<br><br><br>";
        echo "<h3>Agumentin<br>Parol<br>Calpol</h3>";
    
      

      default:
      echo "";

    }
}



?>
               </li>
  
            </ul> </article>
        
      </div>
     </div>
  </div>  
 </section> 
 
 </div>
<div class="block"> 
    
      <footer>
    <div class="main aligncenter">
      <div class="privacy">E-czanem   &copy; 2022  <a href="index-5.html" rel="nofollow"></a></div>
        </div>
  </footer>
    </div>
</body>
</html>